#!/bin/bash

dl_url="https://dl.ecoo.top/update/system"

readonly COLOUR_RESET='\e[0m'
declare -A COLORS
COLORS=(
    ["red"]='\e[91m'
    ["green"]='\e[32;1m' 
    ["yellow"]='\e[33m'
)

printStr() {
    color=$1
    printf ${COLORS[${color}]}"$2"${COLOUR_RESET}"\n"
	return 0
}

_exit() {
    exit_singal=$1
    shift
    [ "$exit_singal" != "0" ] && printStr red "$*" || printStr green "$*"
    exit $exit_singal
}

get_md5() {
    case $1 in
    -c)
        shift
        wget -q $1 -O - | grep $2 | awk '{print $1}'
        ;;
    -l)
        shift
        [ ! -f "$1" ] && return 1
        md5sum $1 2> /dev/null | awk '{print $1}'
        ;;
    esac
	return 0
}

echo "
+----------------------------------------------------------------------
| 海纳思系统hi3798mv100升级系统专用脚本温馨提示：
+----------------------------------------------------------------------
| 此专用脚本可以让你在任意版本的NAS系统下一键升级到20221001,
+----------------------------------------------------------------------
| 升级202210版专用，原系统将完全清除，请注意保存资料。
+----------------------------------------------------------------------
| 如果不确定，请按CTRL+C结束此脚本.
+----------------------------------------------------------------------
"
read -p "继续执行？[y/n]: " result
[ "${result^^}" != "Y" ] && exit

model=$(egrep -oa "hi3798.+reg" /dev/mmcblk0p1 2> /dev/null | cut -d '_' -f1 | sort | uniq)
platform=$(egrep -oa 'mdmo.+' <<< $model | cut -c5)

if [ "$(echo ${model:6:5})" != "mdmo$platform" ];then
	_exit 1 "本升级程序仅支持hi1798mv${platform}00机型！"
fi

if [ $(whoami) != "root" ];then
	_exit 1 "请使用root权限切换系统命令！"
fi

space_left=$(df -hT|grep /dev/root|awk '{print $4}')
if [ "$(expr $(echo ${space_left%%G}) \> 1)" != 1 ];then
	_exit 1 "请确保剩余空间大于1G！"
fi

[ "${platform}" != "1" ] && suffixbit="-64"
dlfile="$(echo ${model:6:6})${suffixbit}.flash"

printStr yellow "下载刷机包...移动网速度稍慢，电信和联通速度很快"
wget -q --show-progress --no-check-certificate ${dl_url}/${dlfile} -O /${dlfile} || _exit 1 "下载失败，请重试"
printStr yellow "校验刷机包..."
[ "$(get_md5 -c ${dl_url}/md5sum ${dlfile})" != "$(get_md5 -l /${dlfile})" ] && _exit 1 "文件校验失败，请重试"
printStr green "下载完成！"

printStr yellow "刷机中，请勿断电..."
dd if=/${dlfile} of=/dev/mmcblk0 bs=1024 status=progress

[[ $? == 0 ]] && printStr yellow "
==============================================================
刷机已完成，请手工关闭电源并再次开启，等待初始化3-5分钟即可。
==============================================================" || \
	_exit 1 "刷机失败"


