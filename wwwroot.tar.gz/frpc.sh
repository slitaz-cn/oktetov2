#!/bin/bash

token=vipuser8088
sed "s/aaaaaaaa/$token/g" /etc/frp/frpc.ini

